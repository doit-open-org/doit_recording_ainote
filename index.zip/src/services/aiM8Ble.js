import {
  DeviceEventEmitter,
  NativeEventEmitter,
  NativeModules,
  Platform,
} from "react-native";
import RNFS from "react-native-fs";
import NativeLocalStorage from "../../specs/NativeLocalStorage";
import {
  COMMAND,
  UUIDS,
  buildDeleteFileRequest,
  buildFileDataRequest,
  buildRequest,
  buildSetTimeRequest,
  bytesToHex,
  concatBytes,
  createControlFrameDecoder,
  hexToBytes,
  normalizeHex,
  parseDeviceInfo,
  parseDeviceStatus,
  parseFileRecord,
  parseRecordingInfo,
  parseWifiCredentials,
  readUInt32BE,
} from "../utils/protocol";
import { parseJsonValue, parseNativeBleMessage } from "../utils/nativeBleEvent";
import { resolveAiM8Identity } from "../utils/deviceIdentity";

const NATIVE_EVENT = "callJsRnBle";
const NATIVE_WIFI_EVENT = "callJsRnWifi";
const DEFAULT_MTU = 23;
const REQUESTED_MTU = 512;
const MIN_CONTROL_MTU = 59;
const MTU_TIMEOUT_MS = 4000;
const RESPONSE_TIMEOUT_MS = 6000;
const NOTIFY_SETTLE_MS = 900;
const DOWNLOAD_IDLE_TIMEOUT_MS = 12000;
const DOWNLOAD_FLUSH_BYTES = 48 * 1024;
const WIFI_CONNECT_TIMEOUT_MS = 35000;
const WIFI_RESPONSE_TIMEOUT_MS = 8000;
const WIFI_DOWNLOAD_FINISH_DELAY_MS = 700;
const PANEL_URL = "2026091513500001";
const BASE64_ALPHABET =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

function sameMac(left, right) {
  return (
    String(left || "")
      .replace(/[^0-9a-f]/gi, "")
      .toUpperCase() ===
    String(right || "")
      .replace(/[^0-9a-f]/gi, "")
      .toUpperCase()
  );
}

function sameUuid(left, right) {
  return String(left || "").toLowerCase() === String(right || "").toLowerCase();
}

function bytesToBase64(bytes) {
  let output = "";
  for (let offset = 0; offset < bytes.length; offset += 3) {
    const first = bytes[offset];
    const second = offset + 1 < bytes.length ? bytes[offset + 1] : 0;
    const third = offset + 2 < bytes.length ? bytes[offset + 2] : 0;
    const value = (first << 16) | (second << 8) | third;
    output += BASE64_ALPHABET[(value >>> 18) & 63];
    output += BASE64_ALPHABET[(value >>> 12) & 63];
    output +=
      offset + 1 < bytes.length ? BASE64_ALPHABET[(value >>> 6) & 63] : "=";
    output += offset + 2 < bytes.length ? BASE64_ALPHABET[value & 63] : "=";
  }
  return output;
}

function base64ToBytes(value) {
  const text = String(value || "").replace(/\s/g, "");
  if (!text) return new Uint8Array();
  const output = [];
  let buffer = 0;
  let bits = 0;
  for (const char of text) {
    if (char === "=") break;
    const index = BASE64_ALPHABET.indexOf(char);
    if (index < 0) continue;
    buffer = (buffer << 6) | index;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      output.push((buffer >>> bits) & 0xff);
    }
  }
  return Uint8Array.from(output);
}

function createAiM8BleClient({
  mac,
  deviceId,
  connected = false,
  wifiHost,
  wifiPort,
}) {
  const identity = resolveAiM8Identity(deviceId, mac);
  mac = identity.mac || mac;
  let isConnected = Boolean(connected);
  let negotiatedMtu = DEFAULT_MTU;
  let subscription = null;
  let wifiSubscription = null;
  let nativeEmitter = null;
  let serial = 0;
  let waiters = [];
  let mtuWaiters = [];
  let writeRequests = new Map();
  let activeDownload = null;
  let wifiState = "idle";
  let wifiConnectedAt = 0;
  let wifiSessionId = "";
  let wifiInfo = null;
  let wifiControlBuffer = new Uint8Array();
  let wifiRequests = new Map();
  let wifiFrameWaiters = [];
  let operationQueue = Promise.resolve();
  const controlDecoder = createControlFrameDecoder();
  const connectionListeners = new Set();
  const controlListeners = new Set();
  const wifiStateListeners = new Set();
  const connectionTrace = [];
  let traceWrite = Promise.resolve();
  function traceConnection(event, details = {}) {
    connectionTrace.push({ time: new Date().toISOString(), event, ...details });
    if (connectionTrace.length > 60) connectionTrace.shift();
    const report = JSON.stringify(connectionTrace);
    traceWrite = traceWrite
      .catch(() => undefined)
      .then(() =>
        RNFS.writeFile(
          `${RNFS.DocumentDirectoryPath}/ainote-connection.json`,
          report,
          "utf8",
        ),
      );
    traceWrite.catch(() => undefined);
  }

  function wait(delayMs) {
    return new Promise((resolve) => setTimeout(resolve, delayMs));
  }

  function sendNative(type, data) {
    if (!NativeLocalStorage?.sendThirdBleData) {
      throw new Error("宿主 App 未注册第三方蓝牙接口");
    }
    return NativeLocalStorage.sendThirdBleData(
      JSON.stringify({ type, device_id: deviceId, data }),
    );
  }

  function setWifiState(state, details = {}) {
    traceConnection("wifi-state", { state, message: details.message });
    wifiState = state;
    wifiStateListeners.forEach((listener) =>
      listener({ state, sessionId: wifiSessionId, ...details }),
    );
  }

  function waitForWifiRequest(requestId, timeoutMs, timeoutText) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        wifiRequests.delete(requestId);
        reject(new Error(timeoutText));
      }, timeoutMs);
      wifiRequests.set(requestId, { resolve, reject, timer });
    });
  }

  function sendWifiNative(type, data, timeoutMs, timeoutText) {
    const requestId = data.requestId || `ainote-wifi-${Date.now()}-${++serial}`;
    const reply = waitForWifiRequest(requestId, timeoutMs, timeoutText);
    try {
      sendNative(type, { ...data, requestId });
    } catch (error) {
      const pending = wifiRequests.get(requestId);
      if (pending) {
        clearTimeout(pending.timer);
        wifiRequests.delete(requestId);
        pending.reject(error);
      }
    }
    return reply;
  }

  function rejectWifiRequests(error) {
    const pending = Array.from(wifiRequests.values());
    wifiRequests.clear();
    pending.forEach((request) => {
      clearTimeout(request.timer);
      request.reject(error);
    });
  }

  function persistDevice({
    deviceName,
    pid,
    bindTimestamp = Math.floor(Date.now() / 1000),
  }) {
    if (!mac || !deviceId || !pid) {
      console.warn(
        "[AiNotePanel] skip device persistence: missing launch parameters",
        {
          hasMac: Boolean(mac),
          hasDeviceId: Boolean(deviceId),
          hasPid: Boolean(pid),
        },
      );
      return null;
    }
    return sendNative(1012, {
      bindTimestamp: String(bindTimestamp),
      deviceId: identity.persistentDeviceId,
      deviceName: String(deviceName || "Ai-M8"),
      mac,
      mpaasUrl: PANEL_URL,
      pid: String(pid),
    });
  }

  function emitConnection(next) {
    traceConnection("ble-state", { connected: Boolean(next) });
    const value = Boolean(next);
    if (isConnected === value) return;
    isConnected = value;
    connectionListeners.forEach((listener) => listener(value));
    if (!value) {
      negotiatedMtu = DEFAULT_MTU;
      controlDecoder.reset();
      rejectWaiters(new Error("设备蓝牙连接已断开"));
      rejectMtuWaiters(new Error("设备蓝牙连接已断开"));
      if (activeDownload?.transport !== "wifi") {
        failDownload(new Error("下载因蓝牙断开而中止"));
      }
    }
  }

  function settleWaiters(frame) {
    waiters = waiters.filter((waiter) => {
      if (!waiter.predicate(frame)) return true;
      clearTimeout(waiter.timer);
      waiter.resolve(frame);
      return false;
    });
  }

  function rejectWaiters(error) {
    const pending = waiters;
    waiters = [];
    pending.forEach((waiter) => {
      clearTimeout(waiter.timer);
      waiter.reject(error);
    });
  }

  function rejectMtuWaiters(error) {
    const pending = mtuWaiters;
    mtuWaiters = [];
    pending.forEach((waiter) => {
      clearTimeout(waiter.timer);
      waiter.reject(error);
    });
  }

  function requestMtu() {
    if (!isConnected) {
      return Promise.reject(new Error("设备未连接"));
    }
    if (negotiatedMtu >= MIN_CONTROL_MTU) {
      return Promise.resolve(negotiatedMtu);
    }
    return new Promise((resolve, reject) => {
      const waiter = { resolve, reject, timer: null };
      waiter.timer = setTimeout(() => {
        mtuWaiters = mtuWaiters.filter((item) => item !== waiter);
        reject(new Error("蓝牙 MTU 协商超时"));
      }, MTU_TIMEOUT_MS);
      mtuWaiters.push(waiter);
      try {
        sendNative(1006, { mac, size: REQUESTED_MTU });
      } catch (error) {
        clearTimeout(waiter.timer);
        mtuWaiters = mtuWaiters.filter((item) => item !== waiter);
        reject(error);
      }
    });
  }

  function waitForControl(
    predicate,
    timeoutMs = RESPONSE_TIMEOUT_MS,
    timeoutText = "等待设备响应超时",
  ) {
    return new Promise((resolve, reject) => {
      const waiter = { predicate, resolve, reject, timer: null };
      waiter.timer = setTimeout(() => {
        waiters = waiters.filter((item) => item !== waiter);
        reject(new Error(timeoutText));
      }, timeoutMs);
      waiters.push(waiter);
    });
  }

  function flushDownload() {
    const task = activeDownload;
    if (!task || !task.bufferHex) return;
    const hex = task.bufferHex;
    task.bufferHex = "";
    task.bufferedBytes = 0;
    task.writeChain = task.writeChain.then(() =>
      RNFS.appendFile(task.tempPath, bytesToBase64(hexToBytes(hex)), "base64"),
    );
  }

  function armDownloadTimeout() {
    const task = activeDownload;
    if (!task) return;
    clearTimeout(task.timer);
    task.timer = setTimeout(() => {
      if (task.transport === "wifi") {
        const phase = task.wifiPhase === "start" ? "等待开始包" : "接收文件";
        const progress = `${task.received}/${task.expectedSize}`;
        const probe = task.wifiProbeHex
          ? `，首包 ${task.wifiProbeHex}`
          : "，未收到数据";
        failDownload(new Error(`Wi-Fi ${phase}超时（${progress}${probe}）`));
        return;
      }
      failDownload(new Error("文件数据接收超时"));
    }, DOWNLOAD_IDLE_TIMEOUT_MS);
  }

  function receiveFileData(pkg) {
    const task = activeDownload;
    if (!task) return;
    const hex = normalizeHex(pkg);
    if (!hex) return;
    const bytes = hex.length / 2;
    if (task.expectedSize && task.received + bytes > task.expectedSize) {
      failDownload(new Error("设备返回的文件数据超过声明大小"));
      return;
    }
    task.bufferHex += hex;
    task.bufferedBytes += bytes;
    task.received += bytes;
    if (task.bufferedBytes >= DOWNLOAD_FLUSH_BYTES) flushDownload();
    task.onProgress?.({
      received: task.received,
      total: task.expectedSize,
      progress: task.expectedSize
        ? Math.min(99, Math.round((task.received / task.expectedSize) * 100))
        : 0,
    });
    armDownloadTimeout();
  }

  async function finishDownload() {
    const task = activeDownload;
    if (!task || task.finishing) return;
    task.finishing = true;
    clearTimeout(task.timer);
    clearTimeout(task.completionTimer);
    flushDownload();
    try {
      await task.writeChain;
      if (!task.expectedSize || task.received !== task.expectedSize) {
        throw new Error(
          `文件大小不一致：${task.received}/${task.expectedSize}`,
        );
      }
      if (await RNFS.exists(task.finalPath)) await RNFS.unlink(task.finalPath);
      await RNFS.moveFile(task.tempPath, task.finalPath);
      activeDownload = null;
      task.onProgress?.({
        received: task.received,
        total: task.expectedSize,
        progress: 100,
      });
      task.resolve({ path: task.finalPath, size: task.received });
    } catch (error) {
      activeDownload = null;
      task.reject(error);
    }
  }

  function failDownload(error) {
    const task = activeDownload;
    if (!task) return;
    activeDownload = null;
    clearTimeout(task.timer);
    clearTimeout(task.completionTimer);
    if (task.tempPath) {
      void RNFS.exists(task.tempPath)
        .then((exists) => (exists ? RNFS.unlink(task.tempPath) : undefined))
        .catch(() => undefined);
    }
    task.reject(error);
  }

  function handleControl(pkg) {
    let frames;
    try {
      frames = controlDecoder.push(pkg);
    } catch (_) {
      return;
    }
    frames.forEach((frame) => {
      settleWaiters(frame);
      controlListeners.forEach((listener) => listener(frame));
      if (
        activeDownload &&
        frame.command === COMMAND.FILE_DATA &&
        frame.payload.length === 1 &&
        frame.payload[0] === 2
      ) {
        void finishDownload();
      }
    });
  }

  function settleWifiFrameWaiters(frame) {
    wifiFrameWaiters = wifiFrameWaiters.filter((waiter) => {
      if (!waiter.predicate(frame)) return true;
      clearTimeout(waiter.timer);
      waiter.resolve(frame);
      return false;
    });
  }

  function waitForWifiFrame(predicate, timeoutText) {
    return new Promise((resolve, reject) => {
      const waiter = { predicate, resolve, reject, timer: null };
      waiter.timer = setTimeout(() => {
        wifiFrameWaiters = wifiFrameWaiters.filter((item) => item !== waiter);
        reject(new Error(timeoutText));
      }, WIFI_RESPONSE_TIMEOUT_MS);
      wifiFrameWaiters.push(waiter);
    });
  }

  function rejectWifiFrameWaiters(error) {
    const pending = wifiFrameWaiters;
    wifiFrameWaiters = [];
    pending.forEach((waiter) => {
      clearTimeout(waiter.timer);
      waiter.reject(error);
    });
  }

  function handleWifiControlBytes(bytes) {
    wifiControlBuffer = concatBytes(wifiControlBuffer, bytes);
    while (wifiControlBuffer.length >= 4) {
      let header = -1;
      for (let index = 0; index + 2 < wifiControlBuffer.length; index += 1) {
        if (
          ((wifiControlBuffer[index] === 0xca &&
            wifiControlBuffer[index + 1] === 0xac) ||
            (wifiControlBuffer[index] === 0xac &&
              wifiControlBuffer[index + 1] === 0xca)) &&
          [COMMAND.FILE_DATA, COMMAND.DELETE_FILE].includes(
            wifiControlBuffer[index + 2],
          )
        ) {
          header = index;
          break;
        }
      }
      if (header < 0) {
        wifiControlBuffer = new Uint8Array();
        return;
      }
      if (header > 0) wifiControlBuffer = wifiControlBuffer.slice(header);
      if (wifiControlBuffer.length < 4) return;
      const frameLength = 4 + wifiControlBuffer[3];
      if (wifiControlBuffer.length < frameLength) return;
      const frame = {
        command: wifiControlBuffer[2],
        payload: wifiControlBuffer.slice(4, frameLength),
      };
      wifiControlBuffer = wifiControlBuffer.slice(frameLength);
      settleWifiFrameWaiters(frame);
    }
  }

  function scheduleWifiDownloadFinish(task) {
    clearTimeout(task.completionTimer);
    task.completionTimer = setTimeout(() => {
      if (activeDownload === task) void finishDownload();
    }, WIFI_DOWNLOAD_FINISH_DELAY_MS);
  }

  function handleWifiDownloadBytes(task, incoming) {
    if (task.wifiProbeHex.length < 96) {
      task.wifiProbeHex = `${task.wifiProbeHex}${bytesToHex(incoming)}`.slice(
        0,
        96,
      );
    }
    task.wifiBuffer = concatBytes(task.wifiBuffer, incoming);
    while (activeDownload === task && task.wifiBuffer.length) {
      if (task.wifiPhase === "start") {
        if (task.wifiBuffer.length < 3) return;
        let header = -1;
        for (let index = 0; index + 2 < task.wifiBuffer.length; index += 1) {
          if (
            ((task.wifiBuffer[index] === 0xca &&
              task.wifiBuffer[index + 1] === 0xac) ||
              (task.wifiBuffer[index] === 0xac &&
                task.wifiBuffer[index + 1] === 0xca)) &&
            task.wifiBuffer[index + 2] === COMMAND.FILE_DATA
          ) {
            header = index;
            break;
          }
        }
        if (header < 0) {
          console.log(
            "[AiNotePanel] waiting for Wi-Fi download header",
            bytesToHex(task.wifiBuffer.slice(0, 24)),
          );
          task.wifiBuffer = task.wifiBuffer.slice(
            Math.max(0, task.wifiBuffer.length - 2),
          );
          return;
        }
        if (header > 0) {
          console.log(
            "[AiNotePanel] ignored bytes before Wi-Fi download header",
            bytesToHex(task.wifiBuffer.slice(0, Math.min(header, 24))),
          );
          task.wifiBuffer = task.wifiBuffer.slice(header);
        }
        if (task.wifiBuffer.length < 4) return;
        const packetLength = 4 + task.wifiBuffer[3];
        if (task.wifiBuffer.length < packetLength) return;
        const packet = task.wifiBuffer.slice(0, packetLength);
        task.wifiBuffer = task.wifiBuffer.slice(packetLength);
        const standardResponse = packet[0] === 0xac && packet[1] === 0xca;
        let declaredSize = 0;
        if (standardResponse) {
          if (packet[3] !== 5 || packet.length < 9 || packet[4] !== 0) {
            failDownload(
              new Error(
                `设备拒绝通过 Wi-Fi 发送这条录音（${packet[4] ?? "未知"}）`,
              ),
            );
            return;
          }
          declaredSize = readUInt32BE(packet, 5);
        } else {
          if (packet[3] !== 6 || packet.length < 10) {
            failDownload(new Error("设备拒绝通过 Wi-Fi 发送这条录音"));
            return;
          }
          declaredSize = readUInt32BE(packet, 6);
        }
        if (!declaredSize || declaredSize !== task.expectedSize) {
          failDownload(
            new Error(
              `Wi-Fi 文件大小不一致：${declaredSize}/${task.expectedSize}`,
            ),
          );
          return;
        }
        task.wifiPhase = "data";
        console.log("[AiNotePanel] Wi-Fi start", { size: declaredSize });
        armDownloadTimeout();
        continue;
      }

      if (task.wifiPhase === "data") {
        const remaining = task.expectedSize - task.received;
        if (remaining <= 0) {
          task.wifiPhase = "end";
          scheduleWifiDownloadFinish(task);
          continue;
        }
        const count = Math.min(remaining, task.wifiBuffer.length);
        const chunk = task.wifiBuffer.slice(0, count);
        task.wifiBuffer = task.wifiBuffer.slice(count);
        receiveFileData(bytesToHex(chunk));
        if (task.received === task.expectedSize) {
          task.wifiPhase = "end";
          scheduleWifiDownloadFinish(task);
        }
        continue;
      }

      if (task.wifiPhase === "end") {
        if (task.wifiBuffer.length < 5) return;
        if (
          task.wifiBuffer[0] === 0xac &&
          task.wifiBuffer[1] === 0xca &&
          task.wifiBuffer[2] === COMMAND.FILE_DATA &&
          task.wifiBuffer[3] === 1 &&
          task.wifiBuffer[4] === 2
        ) {
          task.wifiBuffer = task.wifiBuffer.slice(5);
          void finishDownload();
          return;
        }
        if (task.wifiBuffer.length < 6) return;
        if (
          task.wifiBuffer[0] === 0xca &&
          task.wifiBuffer[1] === 0xac &&
          task.wifiBuffer[2] === COMMAND.FILE_DATA &&
          task.wifiBuffer[3] === 2 &&
          task.wifiBuffer[4] === 2 &&
          task.wifiBuffer[5] === 0
        ) {
          task.wifiBuffer = task.wifiBuffer.slice(6);
          void finishDownload();
          return;
        }
        task.wifiBuffer = task.wifiBuffer.slice(1);
      }
    }
  }

  function handleWifiBytes(bytes) {
    const task = activeDownload;
    if (task?.transport === "wifi") {
      handleWifiDownloadBytes(task, bytes);
      return;
    }
    handleWifiControlBytes(bytes);
  }

  function handleNativeWifiEvent(raw) {
    const message = parseNativeBleMessage(raw);
    const data = parseJsonValue(message?.data) || {};
    if (!message || Number(message.type) !== 2512) return;
    const state = String(data.state || "");
    const requestId = String(data.requestId || "");
    if (state !== "data")
      traceConnection("native-wifi", {
        state,
        requestId,
        sessionId: data.sessionId,
        code: data.code,
        message: data.message,
      });
    if (data.sessionId) wifiSessionId = String(data.sessionId);

    if (state === "data") {
      handleWifiBytes(base64ToBytes(data.base64));
      return;
    }
    if (state === "wifiConnecting" || state === "wifiConnected") {
      setWifiState("connecting", { nativeState: state });
    } else if (state === "tcpConnecting") {
      setWifiState("connecting", { nativeState: state });
    } else if (state === "tcpConnected") {
      wifiConnectedAt = Date.now();
      setWifiState("ready", { nativeState: state, ...wifiInfo });
    } else if (state === "closed") {
      wifiSessionId = "";
      setWifiState("idle");
      rejectWifiFrameWaiters(new Error("Wi-Fi 快传已关闭"));
      if (activeDownload?.transport === "wifi") {
        failDownload(new Error("Wi-Fi 快传已关闭"));
      }
    } else if (state === "error") {
      const error = new Error(data.message || "Wi-Fi 快传连接失败");
      wifiSessionId = "";
      setWifiState("error", { code: data.code, message: error.message });
      rejectWifiFrameWaiters(error);
      if (activeDownload?.transport === "wifi") failDownload(error);
    }

    if (requestId) {
      const pending = wifiRequests.get(requestId);
      if (
        pending &&
        ["tcpConnected", "writeComplete", "closed", "error"].includes(state)
      ) {
        clearTimeout(pending.timer);
        wifiRequests.delete(requestId);
        state === "error"
          ? pending.reject(new Error(data.message || "Wi-Fi 操作失败"))
          : pending.resolve(data);
      }
    }
  }

  function handleNativeEvent(raw) {
    const message = parseNativeBleMessage(raw);
    const data = parseJsonValue(message?.data) || {};
    if (!message || (data.mac && mac && !sameMac(data.mac, mac))) return;
    const type = Number(message.type);
    if (type === 2007 || type === 2010) {
      emitConnection(Number(data.connectStatus) === 1);
      return;
    }
    if (type === 2012) {
      emitConnection(false);
      return;
    }
    if (type === 2008 || type === 2009) {
      emitConnection(true);
    }
    if (type === 2205 && Number(data.mtu) >= 23) {
      negotiatedMtu = Number(data.mtu);
      const pending = mtuWaiters;
      mtuWaiters = [];
      pending.forEach((waiter) => {
        clearTimeout(waiter.timer);
        waiter.resolve(negotiatedMtu);
      });
    }
    if (type === 2203 && data.sn) {
      const pending = writeRequests.get(String(data.sn));
      if (pending) {
        clearTimeout(pending.timer);
        writeRequests.delete(String(data.sn));
        Number(data.status) === 1
          ? pending.resolve()
          : pending.reject(new Error("蓝牙指令发送失败"));
      }
      return;
    }
    if (type !== 2200) return;
    if (sameUuid(data.chacUuid, UUIDS.control)) {
      handleControl(data.pkg);
    }
    if (sameUuid(data.chacUuid, UUIDS.offline)) receiveFileData(data.pkg);
  }

  function enableNotification(notifyUuid) {
    if (!mac || !isConnected) return;
    sendNative(1003, {
      mac,
      serviceUuid: UUIDS.service,
      notifyUuid,
      enable: true,
    });
  }

  function enableControlNotification() {
    try {
      enableNotification(UUIDS.control);
    } catch (_) {}
  }

  function start() {
    if (!subscription) {
      const eventModule = NativeModules?.NativeEventSendModule;
      if (Platform.OS === "ios" && eventModule) {
        eventModule.myInit?.();
        nativeEmitter = new NativeEventEmitter(eventModule);
        subscription = nativeEmitter.addListener(
          NATIVE_EVENT,
          handleNativeEvent,
        );
        wifiSubscription = nativeEmitter.addListener(
          NATIVE_WIFI_EVENT,
          handleNativeWifiEvent,
        );
      } else {
        subscription = DeviceEventEmitter.addListener(
          NATIVE_EVENT,
          handleNativeEvent,
        );
        wifiSubscription = DeviceEventEmitter.addListener(
          NATIVE_WIFI_EVENT,
          handleNativeWifiEvent,
        );
      }
    }
    if (mac) {
      try {
        sendNative(1007, { mac });
      } catch (_) {}
    }
  }

  function stop() {
    traceConnection("panel-stop", { sessionId: wifiSessionId });
    if (wifiSessionId) {
      try {
        sendNative(1514, {
          requestId: `ainote-wifi-close-${Date.now()}`,
          sessionId: wifiSessionId,
          removeWifi: true,
        });
      } catch (_) {}
    }
    subscription?.remove();
    wifiSubscription?.remove();
    subscription = null;
    wifiSubscription = null;
    nativeEmitter = null;
    rejectWaiters(new Error("页面已关闭"));
    rejectMtuWaiters(new Error("页面已关闭"));
    writeRequests.forEach((pending) => {
      clearTimeout(pending.timer);
      pending.reject(new Error("页面已关闭"));
    });
    writeRequests.clear();
    controlDecoder.reset();
    wifiControlBuffer = new Uint8Array();
    rejectWifiRequests(new Error("页面已关闭"));
    rejectWifiFrameWaiters(new Error("页面已关闭"));
    failDownload(new Error("页面已关闭"));
  }

  function connect() {
    if (!mac) return Promise.reject(new Error("宿主 App 未提供设备 MAC"));
    if (isConnected) return Promise.resolve();
    start();
    return new Promise((resolve, reject) => {
      const remove = onConnectionChange((value) => {
        if (value) {
          clearTimeout(timer);
          remove();
          resolve();
        }
      });
      const timer = setTimeout(() => {
        remove();
        reject(new Error("连接设备超时"));
      }, 12000);
      try {
        sendNative(1009, { mac, timeout: 10000 });
      } catch (error) {
        clearTimeout(timer);
        remove();
        reject(error);
      }
    });
  }

  function sendFrame(frame) {
    if (!isConnected) return Promise.reject(new Error("设备未连接"));
    const sn = `ainote-${Date.now()}-${++serial}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        writeRequests.delete(sn);
        reject(new Error("蓝牙写入超时"));
      }, RESPONSE_TIMEOUT_MS);
      writeRequests.set(sn, { resolve, reject, timer });
      try {
        sendNative(1000, {
          mac,
          serviceUuid: UUIDS.service,
          chacUuid: UUIDS.write,
          pkgs: [bytesToHex(frame)],
          sn,
          mtu: negotiatedMtu,
          timeout: RESPONSE_TIMEOUT_MS,
          needFaq: true,
          fastMode: false,
        });
      } catch (error) {
        clearTimeout(timer);
        writeRequests.delete(sn);
        reject(error);
      }
    });
  }

  function enqueue(operation) {
    const next = operationQueue.catch(() => undefined).then(operation);
    operationQueue = next.catch(() => undefined);
    return next;
  }

  function request(
    command,
    data = new Uint8Array(),
    predicate = () => true,
    label = `命令 0x${command.toString(16).padStart(2, "0").toUpperCase()}`,
  ) {
    return enqueue(async () => {
      const reply = waitForControl(
        (frame) => frame.command === command && predicate(frame.payload),
        RESPONSE_TIMEOUT_MS,
        `${label}响应超时`,
      );
      await sendFrame(buildRequest(command, data));
      return reply;
    });
  }

  function setPhoneType() {
    return request(
      COMMAND.SET_PHONE_TYPE,
      Uint8Array.from([0]),
      () => true,
      "设置手机类型",
    );
  }

  function setTime(date = new Date()) {
    return enqueue(async () => {
      const reply = waitForControl(
        (frame) => frame.command === COMMAND.SET_TIME,
        RESPONSE_TIMEOUT_MS,
        "同步设备时间响应超时",
      );
      await sendFrame(buildSetTimeRequest(date));
      return reply;
    });
  }

  async function queryDeviceInfo() {
    const frame = await request(
      COMMAND.DEVICE_INFO,
      new Uint8Array(),
      () => true,
      "读取设备信息",
    );
    return parseDeviceInfo(frame.payload);
  }

  async function queryRecordingInfo() {
    const frame = await request(
      COMMAND.RECORDING_INFO,
      new Uint8Array(),
      () => true,
      "读取录音状态",
    );
    return parseRecordingInfo(frame.payload, frame.command);
  }

  function queryFileList() {
    return enqueue(
      () =>
        new Promise(async (resolve, reject) => {
          const files = [];
          let timer;
          const listener = (frame) => {
            if (frame.command !== COMMAND.FILE_LIST) return;
            if (frame.payload.length === 1) {
              if (frame.payload[0] === 2) {
                cleanup();
                resolve(files);
              } else if (frame.payload[0] === 1) {
                cleanup();
                reject(new Error("设备文件列表读取失败"));
              }
              return;
            }
            const file = parseFileRecord(frame.payload);
            if (file) files.push(file);
          };
          const cleanup = () => {
            clearTimeout(timer);
            controlListeners.delete(listener);
          };
          controlListeners.add(listener);
          timer = setTimeout(() => {
            cleanup();
            reject(new Error("读取设备文件列表超时"));
          }, RESPONSE_TIMEOUT_MS);
          try {
            await sendFrame(buildRequest(COMMAND.FILE_LIST));
          } catch (error) {
            cleanup();
            reject(error);
          }
        }),
    );
  }

  async function simpleRecordingCommand(command) {
    const frame = await request(command);
    if (frame.payload[0] !== 0) throw new Error("设备拒绝录音操作");
    return parseRecordingInfo(frame.payload, command);
  }

  async function setOption(command, value) {
    const frame = await request(command, Uint8Array.from([value]));
    if (frame.payload.length !== 1 || frame.payload[0] !== 0) {
      throw new Error("设备拒绝修改设置");
    }
  }

  async function openWifiTransport() {
    if (wifiState === "ready") return { ...wifiInfo, sessionId: wifiSessionId };
    if (!isConnected) throw new Error("请先连接录音笔");
    if (activeDownload) throw new Error("文件传输结束后再开启 Wi-Fi 快传");
    if (
      !String(wifiHost || "").trim() ||
      !Number.isInteger(Number(wifiPort)) ||
      Number(wifiPort) < 1 ||
      Number(wifiPort) > 65535
    ) {
      throw new Error("Wi-Fi 快传地址未配置");
    }
    setWifiState("opening");
    try {
      const frame = await request(
        COMMAND.WIFI_SWITCH,
        Uint8Array.from([1]),
        () => true,
        "开启 Wi-Fi 快传",
      );
      wifiInfo = parseWifiCredentials(frame.payload);
      start();
      // The AP can acknowledge F3 before its TCP listener has started.
      await wait(1500);
      const result = await sendWifiNative(
        1512,
        {
          deviceId,
          ssid: wifiInfo.ssid,
          password: wifiInfo.password,
          security: "WPA2",
          host: wifiHost,
          port: wifiPort,
          timeout: 30000,
        },
        WIFI_CONNECT_TIMEOUT_MS,
        "连接设备热点超时",
      );
      wifiSessionId = String(result.sessionId || wifiSessionId);
      setWifiState("ready", wifiInfo);
      return { ...wifiInfo, sessionId: wifiSessionId };
    } catch (error) {
      setWifiState("error", {
        message: error?.message || "Wi-Fi 快传连接失败",
      });
      traceConnection("open-failed", { message: error?.message });
      throw error;
    }
  }

  async function closeWifiTransport() {
    if (wifiState === "idle" && !wifiSessionId) return;
    setWifiState("closing");
    if (activeDownload?.transport === "wifi") {
      failDownload(new Error("Wi-Fi 下载已取消"));
    }
    if (isConnected) {
      await request(
        COMMAND.WIFI_SWITCH,
        Uint8Array.from([0]),
        () => true,
        "关闭 Wi-Fi 快传",
      ).catch(() => undefined);
    }
    const sessionId = wifiSessionId;
    if (sessionId) {
      await sendWifiNative(
        1514,
        { sessionId, removeWifi: true },
        WIFI_RESPONSE_TIMEOUT_MS,
        "关闭 Wi-Fi 快传超时",
      ).catch(() => undefined);
    }
    wifiSessionId = "";
    wifiInfo = null;
    wifiControlBuffer = new Uint8Array();
    setWifiState("idle");
  }

  function sendWifiFrame(frame) {
    if (wifiState !== "ready" || !wifiSessionId) {
      return Promise.reject(new Error("Wi-Fi 快传尚未连接"));
    }
    return sendWifiNative(
      1513,
      { sessionId: wifiSessionId, base64: bytesToBase64(frame) },
      WIFI_RESPONSE_TIMEOUT_MS,
      "Wi-Fi 数据发送超时",
    );
  }

  function downloadFileOverBle(file, onProgress) {
    return enqueue(async () => {
      if (activeDownload) throw new Error("已有文件正在下载");
      enableNotification(UUIDS.offline);
      await wait(NOTIFY_SETTLE_MS);
      const directory = `${RNFS.DocumentDirectoryPath}/AiNote`;
      const finalPath = `${directory}/${file.fileName}.aac`;
      const tempPath = `${finalPath}.part`;
      await RNFS.mkdir(directory);
      if (await RNFS.exists(tempPath)) await RNFS.unlink(tempPath);
      await RNFS.writeFile(tempPath, "", "base64");
      let resolveDone;
      let rejectDone;
      const done = new Promise((resolve, reject) => {
        resolveDone = resolve;
        rejectDone = reject;
      });
      activeDownload = {
        bufferHex: "",
        bufferedBytes: 0,
        expectedSize: file.size,
        finalPath,
        finishing: false,
        onProgress,
        received: 0,
        reject: rejectDone,
        resolve: resolveDone,
        tempPath,
        timer: null,
        completionTimer: null,
        transport: "ble",
        writeChain: Promise.resolve(),
      };
      armDownloadTimeout();
      try {
        const startReply = waitForControl(
          (frame) =>
            frame.command === COMMAND.FILE_DATA &&
            frame.payload.length === 5 &&
            frame.payload[0] === 0,
          RESPONSE_TIMEOUT_MS,
          "开始下载响应超时",
        );
        await sendFrame(buildFileDataRequest(file.fileName, 0));
        await startReply;
        return await done;
      } catch (error) {
        failDownload(error);
        throw error;
      }
    });
  }

  function downloadFileOverWifi(file, onProgress) {
    return enqueue(async () => {
      if (activeDownload) throw new Error("已有文件正在下载");
      if (wifiState !== "ready" || !wifiSessionId) {
        throw new Error("Wi-Fi 快传尚未连接");
      }
      const directory = `${RNFS.DocumentDirectoryPath}/AiNote`;
      const finalPath = `${directory}/${file.fileName}.aac`;
      const tempPath = `${finalPath}.part`;
      await RNFS.mkdir(directory);
      if (await RNFS.exists(tempPath)) await RNFS.unlink(tempPath);
      await RNFS.writeFile(tempPath, "", "base64");
      let resolveDone;
      let rejectDone;
      const done = new Promise((resolve, reject) => {
        resolveDone = resolve;
        rejectDone = reject;
      });
      activeDownload = {
        bufferHex: "",
        bufferedBytes: 0,
        completionTimer: null,
        expectedSize: Number(file.size || 0),
        finalPath,
        finishing: false,
        onProgress,
        received: 0,
        reject: rejectDone,
        resolve: resolveDone,
        tempPath,
        timer: null,
        transport: "wifi",
        wifiBuffer: new Uint8Array(),
        wifiPhase: "start",
        wifiProbeHex: "",
        writeChain: Promise.resolve(),
      };
      armDownloadTimeout();
      try {
        const settleDelay = 1000 - (Date.now() - wifiConnectedAt);
        if (settleDelay > 0) await wait(settleDelay);
        await sendWifiFrame(buildFileDataRequest(file.fileName, 0));
        return await done;
      } catch (error) {
        failDownload(error);
        throw error;
      }
    });
  }

  function downloadFile(file, onProgress) {
    return wifiState === "ready"
      ? downloadFileOverWifi(file, onProgress)
      : downloadFileOverBle(file, onProgress);
  }

  async function cancelDownload() {
    const transport = activeDownload?.transport;
    failDownload(new Error("下载已取消"));
    if (transport === "wifi") {
      await sendWifiFrame(buildRequest(COMMAND.STOP_FILE_DATA)).catch(
        () => undefined,
      );
    } else {
      await request(COMMAND.STOP_FILE_DATA).catch(() => undefined);
    }
  }

  async function deleteFile(fileName) {
    if (wifiState === "ready") {
      const reply = waitForWifiFrame(
        (frame) => frame.command === COMMAND.DELETE_FILE,
        "通过 Wi-Fi 删除设备文件超时",
      );
      await sendWifiFrame(buildDeleteFileRequest(fileName));
      const frame = await reply;
      if (frame.payload.length && frame.payload[0] !== 0) {
        throw new Error("设备文件删除失败");
      }
      return;
    }
    return enqueue(async () => {
      const reply = waitForControl(
        (frame) => frame.command === COMMAND.DELETE_FILE,
      );
      await sendFrame(buildDeleteFileRequest(fileName));
      const frame = await reply;
      if (frame.payload.length !== 1 || frame.payload[0] !== 0) {
        throw new Error("设备文件删除失败");
      }
    });
  }

  function getLocalFilePath(fileName) {
    return `${RNFS.DocumentDirectoryPath}/AiNote/${fileName}.aac`;
  }

  async function findLocalFile(file) {
    const path = getLocalFilePath(file.fileName);
    if (!(await RNFS.exists(path))) return null;
    const stat = await RNFS.stat(path);
    return Number(stat.size) === Number(file.size) ? path : null;
  }

  function onConnectionChange(listener) {
    connectionListeners.add(listener);
    return () => connectionListeners.delete(listener);
  }

  function onControl(listener) {
    controlListeners.add(listener);
    return () => controlListeners.delete(listener);
  }

  function onWifiStateChange(listener) {
    wifiStateListeners.add(listener);
    listener({ state: wifiState, sessionId: wifiSessionId, ...wifiInfo });
    return () => wifiStateListeners.delete(listener);
  }

  async function prepare() {
    if (!isConnected) {
      throw new Error("设备未连接");
    }
    const mtu = await requestMtu();
    if (mtu < MIN_CONTROL_MTU) {
      throw new Error(`蓝牙 MTU 过小（${mtu}），无法读取完整设备信息`);
    }
    let lastError;
    for (let attempt = 0; attempt < 2; attempt += 1) {
      enableControlNotification();
      await wait(NOTIFY_SETTLE_MS + attempt * 400);
      try {
        return await queryDeviceInfo();
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error("设备控制通知通道不可用");
  }

  return {
    cancelDownload,
    connect,
    deleteFile,
    downloadFile,
    findLocalFile,
    getLocalFilePath,
    isConnected: () => isConnected,
    isWifiReady: () => wifiState === "ready",
    closeWifiTransport,
    onConnectionChange,
    onControl,
    onWifiStateChange,
    openWifiTransport,
    pauseRecording: () => simpleRecordingCommand(COMMAND.PAUSE_RECORDING),
    prepare,
    persistDevice,
    queryDeviceInfo,
    queryFileList,
    queryRecordingInfo,
    resumeRecording: () => simpleRecordingCommand(COMMAND.RESUME_RECORDING),
    setAnc: (value) => setOption(COMMAND.SET_ANC, value),
    setPhoneType,
    setSplit: (value) => setOption(COMMAND.SET_SPLIT, value),
    setTime,
    start,
    startRecording: () => simpleRecordingCommand(COMMAND.START_RECORDING),
    stop,
    stopRecording: () => simpleRecordingCommand(COMMAND.STOP_RECORDING),
  };
}

export { createAiM8BleClient };
